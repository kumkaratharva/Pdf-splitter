package com.pdfsplitter.offline

import java.io.File

/** One past split, persisted so it can be shown on the home screen and redone. */
data class HistoryEntry(
    val id: String,
    val originalFileName: String,
    val timestampMillis: Long,
    val totalPages: Int,
    val ranges: List<List<Int>>,
    val sourceFile: File
)
