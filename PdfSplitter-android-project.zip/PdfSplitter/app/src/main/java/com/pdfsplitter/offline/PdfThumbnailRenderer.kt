package com.pdfsplitter.offline

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.Closeable
import java.io.File

/**
 * Thin wrapper around the framework's [PdfRenderer] for generating page thumbnails entirely
 * on-device. Calls are synchronized because PdfRenderer only allows one page open at a time.
 */
class PdfThumbnailRenderer(file: File) : Closeable {

    private val pfd: ParcelFileDescriptor =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)

    val pageCount: Int get() = renderer.pageCount

    /** Renders 0-indexed [pageIndex] to a bitmap [targetWidthPx] wide, preserving aspect ratio. */
    @Synchronized
    fun renderPage(pageIndex: Int, targetWidthPx: Int): Bitmap {
        renderer.openPage(pageIndex).use { page ->
            val scale = targetWidthPx / page.width.toFloat()
            val targetHeightPx = (page.height * scale).toInt().coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(targetWidthPx, targetHeightPx, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bitmap
        }
    }

    @Synchronized
    override fun close() {
        renderer.close()
        pfd.close()
    }
}
