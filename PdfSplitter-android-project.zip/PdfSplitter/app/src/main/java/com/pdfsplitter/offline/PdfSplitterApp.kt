package com.pdfsplitter.offline

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class PdfSplitterApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Loads PDFBox's font/resource data from the APK assets - no network involved.
        PDFBoxResourceLoader.init(applicationContext)
    }
}
