package com.pdfsplitter.offline

import android.graphics.Bitmap
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.pdfsplitter.offline.databinding.ItemPageThumbnailBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PageSelectionState { NONE, ACTIVE }

/**
 * Shows every page of the loaded PDF as a tappable thumbnail. A page is either unselected or
 * "active" (tapped for the range currently being built) - once a range is confirmed, the grid
 * goes back to a clean slate; the chips below the grid are the record of what's been confirmed,
 * not a persistent highlight here. Thumbnails render lazily off the main thread and are cached;
 * a per-view "bound position" tag guards against a slow render landing on a recycled view that
 * has since scrolled away. Long-pressing a page opens a full-size preview via [onLongPress].
 */
class PageThumbnailAdapter(
    private val pageCount: Int,
    private val renderer: PdfThumbnailRenderer,
    private val scope: CoroutineScope,
    private val stateOf: (Int) -> PageSelectionState,
    private val onToggle: (Int) -> Unit,
    private val onLongPress: (Int) -> Unit
) : RecyclerView.Adapter<PageThumbnailAdapter.ThumbViewHolder>() {

    private val cache = LruCache<Int, Bitmap>(50)
    private val thumbWidthPx = 260

    inner class ThumbViewHolder(val binding: ItemPageThumbnailBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ThumbViewHolder {
        val binding = ItemPageThumbnailBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ThumbViewHolder(binding)
    }

    override fun getItemCount() = pageCount

    override fun onBindViewHolder(holder: ThumbViewHolder, position: Int) {
        val pageNumber = position + 1
        val binding = holder.binding
        binding.root.tag = position

        binding.tvPageNum.text = pageNumber.toString()
        applySelectionUi(binding, stateOf(pageNumber))

        val cached = cache.get(position)
        if (cached != null) {
            binding.ivThumb.setImageBitmap(cached)
        } else {
            binding.ivThumb.setImageBitmap(null)
            scope.launch {
                val bmp = try {
                    withContext(Dispatchers.IO) { renderer.renderPage(position, thumbWidthPx) }
                } catch (e: Exception) {
                    null
                }
                if (bmp != null && binding.root.tag == position) {
                    cache.put(position, bmp)
                    binding.ivThumb.setImageBitmap(bmp)
                }
            }
        }

        binding.root.setOnClickListener { onToggle(pageNumber) }
        binding.root.setOnLongClickListener {
            onLongPress(pageNumber)
            true
        }
    }

    private fun applySelectionUi(binding: ItemPageThumbnailBinding, state: PageSelectionState) {
        val density = binding.root.resources.displayMetrics.density
        val context = binding.root.context
        when (state) {
            PageSelectionState.NONE -> {
                binding.ivCheck.visibility = View.GONE
                binding.cardThumb.strokeWidth = (1f * density).toInt()
                binding.cardThumb.setStrokeColor(context.getColor(R.color.stroke))
            }
            PageSelectionState.ACTIVE -> {
                binding.ivCheck.setImageResource(R.drawable.ic_check_circle)
                binding.ivCheck.visibility = View.VISIBLE
                binding.cardThumb.strokeWidth = (2.5f * density).toInt()
                binding.cardThumb.setStrokeColor(context.getColor(R.color.primary))
            }
        }
    }
}
