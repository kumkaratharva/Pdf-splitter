package com.pdfsplitter.offline

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * All PDF work happens on-device. [copyToCache] pulls the picked document's bytes into the
 * app's cache directory once, so both the on-device thumbnail renderer (android.graphics.pdf)
 * and the splitting step (PdfBox-Android) work off a single local File - no network involved.
 */
object PdfSplitterUtil {

    /** Copies the content at [uri] into a local cache file and returns it. */
    fun copyToCache(context: Context, uri: Uri): File {
        val dir = File(context.cacheDir, "pdf_splitter_src")
        if (dir.exists()) dir.deleteRecursively()
        dir.mkdirs()
        val destFile = File(dir, "source.pdf")

        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("Unable to open PDF")
        input.use { inStream ->
            FileOutputStream(destFile).use { outStream ->
                inStream.copyTo(outStream)
            }
        }
        return destFile
    }

    /**
     * Builds one output PDF per entry in [pageGroups] - each entry is a 1-indexed list of page
     * numbers (not necessarily contiguous) to include, in the given order - then bundles all of
     * them into a single ZIP. [onProgress] fires before each group. Returns the resulting ZIP
     * file, written under the app's cache directory.
     */
    fun splitAndZip(
        context: Context,
        sourceFile: File,
        pageGroups: List<List<Int>>,
        baseFileName: String,
        onProgress: (current: Int, total: Int) -> Unit
    ): File {
        val workDir = File(context.cacheDir, "pdf_splitter_out")
        if (workDir.exists()) workDir.deleteRecursively()
        workDir.mkdirs()

        val outputFiles = mutableListOf<File>()
        val sourceDoc = PDDocument.load(sourceFile)
        try {
            pageGroups.forEachIndexed { index, pages ->
                onProgress(index + 1, pageGroups.size)

                val splitDoc = PDDocument()
                try {
                    for (pageNumber in pages) {
                        val page = sourceDoc.getPage(pageNumber - 1)
                        splitDoc.importPage(page)
                    }
                    val outFile = File(workDir, "${baseFileName}_${describePagesForFilename(pages)}.pdf")
                    splitDoc.save(outFile)
                    outputFiles.add(outFile)
                } finally {
                    splitDoc.close()
                }
            }
        } finally {
            sourceDoc.close()
        }

        val zipFile = File(workDir, "${baseFileName}_split.zip")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
            outputFiles.forEach { file ->
                FileInputStream(file).use { fis ->
                    zos.putNextEntry(ZipEntry(file.name))
                    fis.copyTo(zos)
                    zos.closeEntry()
                }
            }
        }
        return zipFile
    }

    /** Collapses a page list into a filesystem-safe suffix, e.g. [1,2,3,7,10] -> "p1-3_p7_p10". */
    private fun describePagesForFilename(pages: List<Int>): String {
        if (pages.isEmpty()) return "empty"
        val sorted = pages.sorted()
        val parts = mutableListOf<String>()
        var start = sorted[0]
        var prev = sorted[0]
        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur == prev + 1) {
                prev = cur
            } else {
                parts.add(if (start == prev) "p$start" else "p$start-$prev")
                start = cur
                prev = cur
            }
        }
        parts.add(if (start == prev) "p$start" else "p$start-$prev")
        return parts.joinToString("_")
    }
}
