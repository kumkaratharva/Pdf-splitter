package com.pdfsplitter.offline

import android.view.View
import com.pdfsplitter.offline.databinding.ItemRangeManualBinding

/** Thin wrapper around one inflated manual range row: a single free-text "pages" field. */
class RangeRow(val binding: ItemRangeManualBinding) {

    val view: View get() = binding.root

    fun getText(): String = binding.etPages.text?.toString() ?: ""

    fun setText(value: String) {
        binding.etPages.setText(value)
    }

    fun setLabel(text: String) {
        binding.tvRangeLabel.text = text
    }

    fun setError(message: String?) {
        binding.tilPages.error = message
    }

    fun setDeleteEnabled(enabled: Boolean) {
        binding.btnDelete.isEnabled = enabled
        binding.btnDelete.alpha = if (enabled) 1f else 0.3f
    }
}
