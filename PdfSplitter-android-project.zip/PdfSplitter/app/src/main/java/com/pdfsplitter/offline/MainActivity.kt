package com.pdfsplitter.offline

import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.format.DateFormat
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.pdfsplitter.offline.databinding.ActivityMainBinding
import com.pdfsplitter.offline.databinding.DialogPageZoomBinding
import com.pdfsplitter.offline.databinding.ItemHistoryEntryBinding
import com.pdfsplitter.offline.databinding.ItemRangeChipBinding
import com.pdfsplitter.offline.databinding.ItemRangeManualBinding
import com.pdfsplitter.offline.databinding.ItemSummaryPillBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Date

/** Result of parsing one manual "pages" field like "1-5, 9, 12-14". */
private data class PageListParseResult(val pages: List<Int>, val error: String?)

class MainActivity : AppCompatActivity() {

    private enum class Mode { VISUAL, MANUAL }
    private enum class Section { HOME, LOADED }

    private lateinit var binding: ActivityMainBinding

    private var currentSection: Section = Section.HOME
    private var sourceFile: File? = null
    private var selectedFileName: String = "document"
    private var totalPages: Int = 0
    private var resultZip: File? = null
    private var isProcessing: Boolean = false
    private var currentMode: Mode = Mode.VISUAL

    private var thumbnailRenderer: PdfThumbnailRenderer? = null
    private var pageAdapter: PageThumbnailAdapter? = null

    /** Ranges the user has confirmed - each entry is one future output PDF's page list, in the
     *  order those pages were selected. */
    private val committedRanges = mutableListOf<List<Int>>()

    /** Pages tapped in Visual mode since the last confirm, in the order they were tapped
     *  (mutableSetOf is a LinkedHashSet under the hood, so insertion order is preserved). */
    private val activeSelection = mutableSetOf<Int>()

    private val manualRows = mutableListOf<RangeRow>()

    private val openDocumentLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onFileSelected(it) }
        }

    private val createDocumentLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            uri?.let { saveZipTo(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        onBackPressedDispatcher.addCallback(this) {
            if (currentSection == Section.LOADED) {
                goHome()
            } else {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }

        binding.btnSelectFile.setOnClickListener { launchPicker() }
        binding.cardSelectFile.setOnClickListener { launchPicker() }
        binding.btnChangeFile.setOnClickListener { launchPicker() }

        binding.tabVisualContainer.setOnClickListener { setMode(Mode.VISUAL) }
        binding.tabManualContainer.setOnClickListener { setMode(Mode.MANUAL) }

        binding.btnSelectAll.setOnClickListener {
            if (isProcessing || totalPages == 0) return@setOnClickListener
            activeSelection.clear()
            activeSelection.addAll(1..totalPages)
            refreshCurrentModeView()
            updateSelectionUi()
        }

        binding.btnClearSelection.setOnClickListener {
            if (isProcessing) return@setOnClickListener
            activeSelection.clear()
            committedRanges.clear()
            refreshCurrentModeView()
            updateSelectionUi()
        }

        binding.btnAddRange.setOnClickListener {
            if (isProcessing || activeSelection.isEmpty()) return@setOnClickListener
            committedRanges.add(activeSelection.toList())
            activeSelection.clear()
            refreshCurrentModeView()
            Toast.makeText(this, getString(R.string.range_locked_toast), Toast.LENGTH_SHORT).show()
            updateSelectionUi()
        }

        binding.btnAddManualRange.setOnClickListener {
            if (isProcessing) return@setOnClickListener
            val lastMax = manualRows
                .mapNotNull { parsePageList(it.getText()).pages.maxOrNull() }
                .maxOrNull()
            val suggested = if (lastMax != null && lastMax + 1 <= totalPages) (lastMax + 1).toString() else ""
            addManualRow(suggested)
        }

        binding.btnSplit.setOnClickListener { performSplit() }

        binding.btnSave.setOnClickListener {
            if (resultZip != null) {
                createDocumentLauncher.launch("${sanitizedBaseName()}_split.zip")
            }
        }

        binding.btnShare.setOnClickListener { shareZip() }

        refreshHomeScreen()
    }

    private fun launchPicker() {
        openDocumentLauncher.launch(arrayOf("application/pdf"))
    }

    // ---------- Home / history ----------

    private fun refreshHomeScreen() {
        binding.projectsContainer.removeAllViews()
        val entries = HistoryStore.list(this)

        binding.tvRecentHeader.visibility = if (entries.isEmpty()) View.GONE else View.VISIBLE

        val dateFormat = DateFormat.getMediumDateFormat(this)
        val timeFormat = DateFormat.getTimeFormat(this)

        entries.forEach { entry ->
            val item = ItemHistoryEntryBinding.inflate(layoutInflater, binding.projectsContainer, false)
            item.tvHistoryName.text = entry.originalFileName
            val date = Date(entry.timestampMillis)
            val totalSelectedPages = entry.ranges.sumOf { it.size }
            item.tvHistoryDetail.text = getString(
                R.string.project_meta,
                entry.ranges.size,
                totalSelectedPages,
                "${dateFormat.format(date)} ${timeFormat.format(date)}"
            )
            item.root.setOnClickListener {
                if (!isProcessing) redoHistoryEntry(entry)
            }
            item.btnHistoryDelete.setOnClickListener {
                HistoryStore.delete(this, entry.id)
                refreshHomeScreen()
            }
            binding.projectsContainer.addView(item.root)
        }
    }

    private fun goHome() {
        currentSection = Section.HOME
        thumbnailRenderer?.close()
        thumbnailRenderer = null
        pageAdapter = null
        sourceFile = null
        resultZip = null
        activeSelection.clear()
        committedRanges.clear()
        binding.manualRangesContainer.removeAllViews()
        manualRows.clear()
        binding.cardResult.visibility = View.GONE

        binding.sectionLoaded.visibility = View.GONE
        binding.sectionHome.visibility = View.VISIBLE
        refreshHomeScreen()
    }

    private fun redoHistoryEntry(entry: HistoryEntry) {
        Toast.makeText(this, getString(R.string.loading_pdf), Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val dir = File(cacheDir, "pdf_splitter_src")
                    if (dir.exists()) dir.deleteRecursively()
                    dir.mkdirs()
                    val dest = File(dir, "source.pdf")
                    entry.sourceFile.copyTo(dest, overwrite = true)
                    dest
                }
                loadSourceIntoGrid(file, entry.originalFileName, prefilledRanges = entry.ranges)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, getString(R.string.error_reading_pdf_detail), Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- File selection ----------

    private fun onFileSelected(uri: Uri) {
        val displayName = queryFileName(uri)
        Toast.makeText(this, getString(R.string.loading_pdf), Toast.LENGTH_SHORT).show()

        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    PdfSplitterUtil.copyToCache(this@MainActivity, uri)
                }
                loadSourceIntoGrid(file, displayName, prefilledRanges = null)
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.error_reading_pdf_detail),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /** Shared setup once a source PDF is available locally, whether from a fresh pick or a
     *  redo. If [prefilledRanges] is non-null, those ranges are pre-confirmed (shown as chips,
     *  ready to split) instead of starting from a blank selection. */
    private suspend fun loadSourceIntoGrid(file: File, displayName: String, prefilledRanges: List<List<Int>>?) {
        selectedFileName = displayName
        resultZip = null
        activeSelection.clear()
        committedRanges.clear()
        binding.manualRangesContainer.removeAllViews()
        manualRows.clear()
        binding.cardResult.visibility = View.GONE

        thumbnailRenderer?.close()
        val renderer = withContext(Dispatchers.IO) { PdfThumbnailRenderer(file) }

        sourceFile = file
        thumbnailRenderer = renderer
        totalPages = renderer.pageCount

        if (prefilledRanges != null) {
            committedRanges.addAll(prefilledRanges.filter { range -> range.all { it in 1..totalPages } })
        }

        binding.tvFileName.text = selectedFileName
        binding.tvFileInfo.text = getString(R.string.page_count_info, totalPages)

        pageAdapter = PageThumbnailAdapter(
            pageCount = totalPages,
            renderer = renderer,
            scope = lifecycleScope,
            stateOf = { pageNumber -> pageStateOf(pageNumber) },
            onToggle = { pageNumber -> onPageToggled(pageNumber) },
            onLongPress = { pageNumber -> showPageZoom(pageNumber) }
        )
        binding.rvPages.layoutManager = GridLayoutManager(this@MainActivity, 3)
        binding.rvPages.itemAnimator = null
        if (binding.rvPages.itemDecorationCount == 0) {
            binding.rvPages.addItemDecoration(
                GridSpacingDecoration((8 * resources.displayMetrics.density).toInt())
            )
        }
        binding.rvPages.adapter = pageAdapter

        currentMode = Mode.VISUAL
        binding.rvPages.visibility = View.VISIBLE
        binding.manualScroll.visibility = View.GONE
        binding.tvModeHint.text = getString(R.string.tap_pages_hint)
        binding.btnAddRange.visibility = View.VISIBLE
        applyTabVisuals()

        currentSection = Section.LOADED
        binding.sectionHome.visibility = View.GONE
        binding.sectionLoaded.visibility = View.VISIBLE
        updateSelectionUi()
    }

    private fun queryFileName(uri: Uri): String {
        var name = "document"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                cursor.getString(idx)?.let { name = it }
            }
        }
        return name
    }

    // ---------- Mode switching ----------

    private fun setMode(mode: Mode) {
        if (currentMode == mode) return
        currentMode = mode
        applyTabVisuals()
        refreshCurrentModeView()
    }

    /** Updates tab colors/underline, content visibility, and the hint text for [currentMode]. */
    private fun applyTabVisuals() {
        val visualActive = currentMode == Mode.VISUAL

        binding.tabVisual.setTextColor(getColor(if (visualActive) R.color.primary else R.color.text_secondary))
        binding.tabManual.setTextColor(getColor(if (!visualActive) R.color.primary else R.color.text_secondary))
        binding.tabVisualIndicator.visibility = if (visualActive) View.VISIBLE else View.INVISIBLE
        binding.tabManualIndicator.visibility = if (!visualActive) View.VISIBLE else View.INVISIBLE

        binding.rvPages.visibility = if (visualActive) View.VISIBLE else View.GONE
        binding.manualScroll.visibility = if (visualActive) View.GONE else View.VISIBLE
        binding.btnAddRange.visibility = if (visualActive) View.VISIBLE else View.GONE
        binding.tvModeHint.text = getString(if (visualActive) R.string.tap_pages_hint else R.string.manual_ranges_hint)
    }

    /** Re-renders whichever mode is currently visible so it reflects the current selection. */
    private fun refreshCurrentModeView() {
        when (currentMode) {
            Mode.VISUAL -> pageAdapter?.notifyDataSetChanged()
            Mode.MANUAL -> populateManualRowsFromSelection()
        }
    }

    // ---------- Visual selection ----------

    private fun pageStateOf(pageNumber: Int): PageSelectionState =
        if (activeSelection.contains(pageNumber)) PageSelectionState.ACTIVE else PageSelectionState.NONE

    private fun onPageToggled(pageNumber: Int) {
        if (isProcessing) return
        if (activeSelection.contains(pageNumber)) activeSelection.remove(pageNumber)
        else activeSelection.add(pageNumber)
        pageAdapter?.notifyItemChanged(pageNumber - 1)
        updateSelectionUi()
    }

    /** Shows a full-size render of one page in a dismissible full-screen overlay. */
    private fun showPageZoom(pageNumber: Int) {
        val renderer = thumbnailRenderer ?: return

        val dialogBinding = DialogPageZoomBinding.inflate(layoutInflater)
        dialogBinding.tvZoomPageNumber.text = getString(R.string.page_number_label, pageNumber)

        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(dialogBinding.root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        dialogBinding.root.setOnClickListener { dialog.dismiss() }
        dialog.show()

        lifecycleScope.launch {
            val targetWidthPx = resources.displayMetrics.widthPixels
            val bmp = try {
                withContext(Dispatchers.IO) { renderer.renderPage(pageNumber - 1, targetWidthPx) }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                dialogBinding.ivZoomImage.setImageBitmap(bmp)
                dialogBinding.progressZoom.visibility = View.GONE
            } else {
                dialog.dismiss()
                Toast.makeText(this@MainActivity, getString(R.string.error_reading_pdf_detail), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Manual selection ----------

    private fun addManualRow(initialText: String = "") {
        val itemBinding = ItemRangeManualBinding.inflate(layoutInflater, binding.manualRangesContainer, false)
        val row = RangeRow(itemBinding)
        manualRows.add(row)
        binding.manualRangesContainer.addView(row.view)

        if (initialText.isNotEmpty()) row.setText(initialText)

        itemBinding.etPages.doAfterTextChanged { onManualRowChanged() }

        itemBinding.btnDelete.setOnClickListener {
            if (isProcessing) return@setOnClickListener
            binding.manualRangesContainer.removeView(row.view)
            manualRows.remove(row)
            relabelManualRows()
            onManualRowChanged()
        }

        relabelManualRows()
    }

    private fun relabelManualRows() {
        manualRows.forEachIndexed { index, row ->
            row.setLabel(getString(R.string.range_label, index + 1))
            row.setDeleteEnabled(manualRows.size > 1)
        }
    }

    /** Rebuilds [committedRanges] from the current manual rows, preserving each row's typed
     *  left-to-right order (not sorted). */
    private fun onManualRowChanged() {
        committedRanges.clear()
        for (row in manualRows) {
            val text = row.getText()
            if (text.isBlank()) {
                row.setError(null)
                continue
            }
            val result = parsePageList(text)
            row.setError(result.error)
            if (result.pages.isNotEmpty()) {
                committedRanges.add(result.pages)
            }
        }
        updateSelectionUi()
    }

    /** Parses "1-5, 9, 12-14" into a de-duplicated page list in the order tokens were typed
     *  left to right (ranges expand ascending), validated against totalPages. */
    private fun parsePageList(text: String): PageListParseResult {
        val pages = mutableSetOf<Int>() // LinkedHashSet - preserves insertion order
        var error: String? = null
        val tokens = text.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        for (token in tokens) {
            if (token.contains("-")) {
                val parts = token.split("-").map { it.trim() }
                val s = parts.getOrNull(0)?.toIntOrNull()
                val e = parts.getOrNull(1)?.toIntOrNull()
                if (parts.size == 2 && s != null && e != null &&
                    s in 1..totalPages && e in 1..totalPages && s <= e
                ) {
                    for (p in s..e) pages.add(p)
                } else {
                    error = getString(R.string.error_invalid_token, token)
                }
            } else {
                val p = token.toIntOrNull()
                if (p != null && p in 1..totalPages) {
                    pages.add(p)
                } else {
                    error = getString(R.string.error_invalid_token, token)
                }
            }
        }
        return PageListParseResult(pages.toList(), error)
    }

    private fun populateManualRowsFromSelection() {
        binding.manualRangesContainer.removeAllViews()
        manualRows.clear()

        val groups = committedRanges + (if (activeSelection.isNotEmpty()) listOf(activeSelection.toList()) else emptyList())

        if (groups.isEmpty()) {
            addManualRow()
        } else {
            groups.forEach { addManualRow(formatPageListForInput(it)) }
        }
    }

    // ---------- Shared: chips / summary / formatting ----------

    private fun updateSelectionUi() {
        binding.chipsContainer.removeAllViews()

        val hasAnything = committedRanges.isNotEmpty() || activeSelection.isNotEmpty()

        if (!hasAnything) {
            binding.tvSelectionHint.visibility = View.VISIBLE
            binding.tvSelectionHint.text = getString(R.string.no_pages_selected)
            binding.chipsScroll.visibility = View.GONE
        } else {
            binding.tvSelectionHint.visibility = View.GONE
            binding.chipsScroll.visibility = View.VISIBLE

            if (committedRanges.isNotEmpty()) {
                val filesPill = ItemSummaryPillBinding.inflate(layoutInflater, binding.chipsContainer, false)
                filesPill.root.text = getString(R.string.files_count_label, committedRanges.size)
                binding.chipsContainer.addView(filesPill.root)
            }

            committedRanges.forEachIndexed { index, pages ->
                val chip = ItemRangeChipBinding.inflate(layoutInflater, binding.chipsContainer, false)
                chip.tvChipLabel.text = formatPageListForDisplay(pages)
                chip.root.setOnClickListener {
                    if (isProcessing || currentMode != Mode.VISUAL) return@setOnClickListener
                    editCommittedRange(index)
                }
                chip.btnChipRemove.setOnClickListener {
                    if (isProcessing) return@setOnClickListener
                    committedRanges.removeAt(index)
                    refreshCurrentModeView()
                    updateSelectionUi()
                }
                binding.chipsContainer.addView(chip.root)
            }

            if (activeSelection.isNotEmpty()) {
                val activePill = ItemSummaryPillBinding.inflate(layoutInflater, binding.chipsContainer, false)
                activePill.root.text = getString(R.string.active_pages_label, activeSelection.size)
                binding.chipsContainer.addView(activePill.root)
            }
        }

        binding.btnSplit.isEnabled = hasAnything && !isProcessing

        val canAddRange = activeSelection.isNotEmpty() && !isProcessing
        binding.btnAddRange.isEnabled = canAddRange
        binding.btnAddRange.alpha = if (canAddRange) 1f else 0.4f
    }

    /**
     * Reopens a confirmed range for editing: pulls its pages back into the active selection
     * (highlighted, tappable again, in their original order) and removes it from the confirmed
     * list. Any selection already in progress is folded into its own confirmed range first, so
     * it isn't lost.
     */
    private fun editCommittedRange(index: Int) {
        val pagesToEdit = committedRanges.getOrNull(index) ?: return

        if (activeSelection.isNotEmpty()) {
            committedRanges.add(activeSelection.toList())
        }
        activeSelection.clear()
        committedRanges.removeAt(index)
        activeSelection.addAll(pagesToEdit)

        pageAdapter?.notifyDataSetChanged()
        Toast.makeText(this, getString(R.string.editing_range_toast), Toast.LENGTH_SHORT).show()
        updateSelectionUi()
    }

    /** Nicely formatted for display: shows the collapsed "1-3, 7" style only when the pages
     *  are in ascending order; otherwise lists them plainly in their actual (selected) order,
     *  since collapsing ranges wouldn't make sense for a shuffled sequence. */
    private fun formatPageListForDisplay(pages: List<Int>): String =
        if (pages == pages.sorted()) collapseRuns(pages, "\u2013") else pages.joinToString(", ")

    /** Parser-compatible formatting (plain ASCII hyphen) for pre-filling a manual row. */
    private fun formatPageListForInput(pages: List<Int>): String =
        if (pages == pages.sorted()) collapseRuns(pages, "-") else pages.joinToString(", ")

    private fun collapseRuns(pages: List<Int>, dash: String): String {
        if (pages.isEmpty()) return ""
        val sorted = pages.sorted()
        val parts = mutableListOf<String>()
        var start = sorted[0]
        var prev = sorted[0]
        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur == prev + 1) {
                prev = cur
            } else {
                parts.add(if (start == prev) "$start" else "$start$dash$prev")
                start = cur
                prev = cur
            }
        }
        parts.add(if (start == prev) "$start" else "$start$dash$prev")
        return parts.joinToString(", ")
    }

    // ---------- Splitting ----------

    private fun performSplit() {
        val file = sourceFile ?: return

        // Fold any still-pending active selection into a committed range before splitting.
        if (activeSelection.isNotEmpty()) {
            committedRanges.add(activeSelection.toList())
            activeSelection.clear()
            refreshCurrentModeView()
            updateSelectionUi()
        }

        val groups = committedRanges.toList()
        if (groups.isEmpty()) return

        isProcessing = true
        binding.btnSplit.isEnabled = false
        binding.btnSelectAll.isEnabled = false
        binding.btnClearSelection.isEnabled = false
        binding.btnAddRange.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        binding.tvProgressStatus.visibility = View.VISIBLE
        binding.cardResult.visibility = View.GONE

        lifecycleScope.launch {
            try {
                val zip = withContext(Dispatchers.IO) {
                    PdfSplitterUtil.splitAndZip(
                        this@MainActivity, file, groups, sanitizedBaseName()
                    ) { current, total ->
                        runOnUiThread {
                            binding.tvProgressStatus.text =
                                getString(R.string.progress_status, current, total)
                        }
                    }
                }
                resultZip = zip
                binding.tvResultTitle.text = getString(R.string.result_title)
                binding.tvResultSubtitle.text = getString(R.string.result_subtitle, groups.size)
                binding.cardResult.visibility = View.VISIBLE

                withContext(Dispatchers.IO) {
                    HistoryStore.save(this@MainActivity, selectedFileName, totalPages, groups, file)
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.error_splitting, e.message ?: ""),
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                isProcessing = false
                binding.progressBar.visibility = View.GONE
                binding.tvProgressStatus.visibility = View.GONE
                binding.btnSelectAll.isEnabled = true
                binding.btnClearSelection.isEnabled = true
                binding.btnSplit.isEnabled = committedRanges.isNotEmpty() || activeSelection.isNotEmpty()
                val canAddRange = activeSelection.isNotEmpty()
                binding.btnAddRange.isEnabled = canAddRange
                binding.btnAddRange.alpha = if (canAddRange) 1f else 0.4f
            }
        }
    }

    private fun sanitizedBaseName(): String {
        val base = selectedFileName.removeSuffix(".pdf").removeSuffix(".PDF")
        val cleaned = base.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        return cleaned.ifBlank { "document" }
    }

    // ---------- Save / Share ----------

    private fun saveZipTo(destUri: Uri) {
        val zip = resultZip ?: return
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(destUri)?.use { out ->
                        zip.inputStream().use { it.copyTo(out) }
                    } ?: throw IOException("Unable to open output stream")
                }
                Toast.makeText(this@MainActivity, getString(R.string.saved_successfully), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, getString(R.string.error_saving), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareZip() {
        val zip = resultZip ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zip)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_zip)))
    }

    override fun onDestroy() {
        thumbnailRenderer?.close()
        super.onDestroy()
    }
}
