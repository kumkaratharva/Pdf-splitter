package com.pdfsplitter.offline

import android.content.Context
import java.io.File

/**
 * Persists a bounded history of past splits under the app's internal files directory (not
 * cache, so it isn't cleared as aggressively) - each entry keeps its own copy of the source
 * PDF plus a small text metadata file, so a past split can be redone without needing to
 * re-pick the original file. Oldest entries are pruned once [MAX_ENTRIES] is exceeded, to
 * keep storage use bounded.
 */
object HistoryStore {

    private const val MAX_ENTRIES = 15

    /** Saves a completed split. Failures here are swallowed - history is a convenience, not
     *  something that should ever break the actual split the user just ran. */
    fun save(context: Context, originalFileName: String, totalPages: Int, ranges: List<List<Int>>, sourceFile: File) {
        try {
            val id = System.currentTimeMillis().toString()
            val dir = File(historyRoot(context), id)
            dir.mkdirs()
            sourceFile.copyTo(File(dir, "source.pdf"), overwrite = true)
            File(dir, "meta.txt").writeText(buildString {
                appendLine(originalFileName)
                appendLine(id)
                appendLine(totalPages.toString())
                ranges.forEach { appendLine(it.joinToString(",")) }
            })
            prune(context)
        } catch (e: Exception) {
            // Ignored - see kdoc above.
        }
    }

    /** Most recent first. */
    fun list(context: Context): List<HistoryEntry> {
        val root = historyRoot(context)
        if (!root.exists()) return emptyList()
        return (root.listFiles { f -> f.isDirectory } ?: emptyArray())
            .mapNotNull { loadEntry(it) }
            .sortedByDescending { it.timestampMillis }
    }

    fun delete(context: Context, id: String) {
        File(historyRoot(context), id).deleteRecursively()
    }

    private fun loadEntry(dir: File): HistoryEntry? {
        return try {
            val metaFile = File(dir, "meta.txt")
            val sourceFile = File(dir, "source.pdf")
            if (!metaFile.exists() || !sourceFile.exists()) return null

            val lines = metaFile.readLines()
            if (lines.size < 3) return null

            val originalFileName = lines[0]
            val timestamp = lines[1].toLongOrNull() ?: dir.name.toLongOrNull() ?: 0L
            val totalPages = lines[2].toIntOrNull() ?: 0
            val ranges = lines.drop(3)
                .filter { it.isNotBlank() }
                .map { line -> line.split(",").mapNotNull { it.trim().toIntOrNull() } }
                .filter { it.isNotEmpty() }

            if (ranges.isEmpty()) return null
            HistoryEntry(dir.name, originalFileName, timestamp, totalPages, ranges, sourceFile)
        } catch (e: Exception) {
            null
        }
    }

    private fun prune(context: Context) {
        val entries = list(context)
        if (entries.size > MAX_ENTRIES) {
            entries.drop(MAX_ENTRIES).forEach { delete(context, it.id) }
        }
    }

    private fun historyRoot(context: Context): File = File(context.filesDir, "history")
}
