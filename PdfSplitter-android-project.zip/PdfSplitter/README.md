# PDF Splitter

A fully offline Android app. Pick a PDF, tap the pages you want to keep together, and get
back a ZIP file containing a separate PDF for each group of pages you selected. No internet
permission, no account, no cloud upload — everything (reading the PDF, rendering thumbnails,
splitting it, zipping the result) happens on-device.

## Home screen and history

The app opens to a Home screen: a "Choose PDF File" card, and below it, your recent splits
(most recent first, capped at the last 15). Tapping a past split's card copies that same
source PDF back into place and pre-loads its exact page groups as confirmed chips - so you
can just hit **Split PDF** again, or tweak the groups first. Each history entry keeps its own
copy of the source PDF in the app's internal storage (not cache), so redoing a split works
even if the original file has since been moved, renamed, or deleted from wherever you first
picked it. Swipe/tap the trash icon on a card to remove it from history.

## Page order

Pages end up in the output PDF in the order you selected them, not sorted numerically. Tap
pages 5, then 1, then 3, and the output file contains pages in that exact order (5, 1, 3) -
same in Manual mode, where typing "5, 1, 3" preserves that order too (a written range like
"1-5" always expands ascending within itself, but where it sits relative to other typed
pages/ranges is preserved). The chips show pages in ascending "1-3, 7" style when your
selection happens to already be in order, and list them plainly (e.g. "5, 1, 3") otherwise,
since collapsing a shuffled order into ranges wouldn't be meaningful.

## How page selection works

There are two ways to build your ranges, switchable with the **Visual / Manual** toggle at
the top - both edit the same underlying selection, so you can freely switch between them.

**Visual** - every page renders as a thumbnail in a grid. Tap any pages you want, in any
order - they don't need to be next to each other, so tapping pages 1, 5, and 10 builds one
group containing exactly those three pages. When that group is ready, tap **+ Add Range**:
it locks those pages in as a confirmed range (shown green in the grid, with a chip at the
bottom) and clears the active selection completely, so your next taps start a totally fresh
group - even if you tap a page right next to the one you just confirmed. Already-confirmed
pages are protected: tapping one again does nothing (a toast explains why) until you remove
its whole chip, which frees those pages up again.

**Manual** - type page numbers directly instead of tapping thumbnails: one flexible text
field per range, e.g. `1-5, 9, 12-14` - mixing individual pages and ranges freely, same as
Visual mode's non-contiguous groups. An **+ Add Another Range** button adds more rows.

If you tap Split while a Visual selection hasn't been explicitly confirmed with + Add Range
yet, it's automatically folded in as one last range before splitting - you don't have to
remember to confirm the final group.

## What you get in this project

- Kotlin, single-Activity app, Material 3 UI
- File picker via Storage Access Framework (`ACTION_OPEN_DOCUMENT`) — no storage permission
  needed
- Page thumbnails rendered on-device with Android's built-in `android.graphics.pdf.PdfRenderer`
  (no extra library, no network) — lazily rendered and cached as you scroll, so it stays smooth
  even on long documents
- Output files can contain **any set of pages**, not just contiguous spans — pick pages 1, 5,
  and 10 for one file if that's what you need
- Splitting + zipping (via PdfBox-Android) runs on a background thread with a progress
  indicator
- Result screen lets you **Save** the ZIP (via `ACTION_CREATE_DOCUMENT`, so it goes wherever
  you choose — Downloads, Drive, etc.) or **Share** it to another app
- minSdk 26 (Android 8.0+), targetSdk 34

## How to build the APK

This was written as a complete, ready-to-build Android Studio project — but building an
`.apk` requires the Android SDK/build toolchain, which isn't available in the sandbox this
was generated in, so what you're getting is the full source, not a compiled binary. To turn
it into an installable APK:

1. Install **Android Studio** (free, from developer.android.com/studio) if you don't have it
   already.
2. Unzip this project, then in Android Studio: **File → Open** and select the `PdfSplitter`
   folder.
3. Let Gradle sync. This first sync needs internet to download the Android Gradle Plugin,
   Kotlin, and the PdfBox-Android library from Maven Central — after that, the *installed app
   itself* needs zero internet access to run.
   - If Android Studio offers to upgrade the Android Gradle Plugin/Gradle version, it's safe
     to accept.
4. Plug in an Android phone (with USB debugging on) or start an emulator, then click the
   green **Run ▶** button. Or, to just produce an APK file:
   **Build → Build App Bundle(s)/APK(s) → Build APK(s)** — the file lands in
   `app/build/outputs/apk/debug/app-debug.apk`, which you can copy to a phone and install
   directly (allow "install from unknown sources" if prompted).

## Project layout

```
app/src/main/java/com/pdfsplitter/offline/
  PdfSplitterApp.kt          Application class, initializes PdfBox-Android
  MainActivity.kt            UI logic: Home/history, file picking, both selection modes,
                             split, save/share
  HistoryEntry.kt            Data class for one past split
  HistoryStore.kt            Persists past splits (capped, with their own source PDF copy)
  PdfThumbnailRenderer.kt    Renders page thumbnails on-device (android.graphics.pdf)
  PageThumbnailAdapter.kt    RecyclerView grid adapter with async/cached thumbnails
  GridSpacingDecoration.kt   Even spacing between grid cells
  RangeRow.kt                Wrapper around one manual "pages" row
  PdfSplitterUtil.kt         Copies the picked PDF locally, then splits + zips it
app/src/main/res/
  layout/     activity_main.xml, item_page_thumbnail.xml, item_range_chip.xml,
              item_range_manual.xml, item_history_entry.xml, item_summary_pill.xml,
              dialog_page_zoom.xml
  values/     strings.xml, colors.xml, themes.xml
  drawable/, mipmap-anydpi-v26/   icons
```

## Notes / things you may want to change

- **Grid columns**: currently 3 columns (`GridLayoutManager(this, 3)` in `MainActivity.kt`) —
  bump to 4+ for very large PDFs if you'd rather scroll less and see smaller thumbnails.
- **App icon**: a simple placeholder (two overlapping "page" shapes) is included as a vector
  adaptive icon — swap `ic_launcher_foreground.xml` / `ic_launcher_background.xml` for your
  own design any time.
- **minSdk 26**: covers effectively all active Android devices as of 2026. Lower it in
  `app/build.gradle` if you need to support older phones (Android 7.0, API 24) — you'd then
  also need to add legacy PNG launcher icons, since adaptive icons require API 26+.
- **PdfBox-Android** (`com.tom-roush:pdfbox-android`) is Apache-2.0 licensed and handles the
  actual page extraction/writing; thumbnail rendering instead uses Android's own built-in
  `PdfRenderer`, so no extra library is needed for that part.
