'use strict';

pdfjsLib.GlobalWorkerOptions.workerSrc =
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// ---------- State ----------

let pdfDoc = null;          // pdf.js document (for rendering thumbnails/previews)
let pdfBytes = null;        // raw ArrayBuffer of the loaded file (for pdf-lib splitting)
let fileName = 'document';
let totalPages = 0;
let isProcessing = false;
let currentMode = 'visual'; // 'visual' | 'manual'

/** Confirmed ranges - each entry is one future output PDF's page list, in selection order. */
let committedRanges = [];

/** Pages tapped since the last confirm, in the order they were tapped. Array (order) + Set
 *  (fast membership check) kept in sync by the helpers below. */
let activeSelection = [];
let activeSelectionSet = new Set();

let manualRows = [];        // [{ el, input, errorEl, label }]
const thumbnailCache = new Map(); // pageNum -> data URL

function activeAdd(p) {
  if (!activeSelectionSet.has(p)) {
    activeSelectionSet.add(p);
    activeSelection.push(p);
  }
}
function activeRemove(p) {
  if (activeSelectionSet.has(p)) {
    activeSelectionSet.delete(p);
    const idx = activeSelection.indexOf(p);
    if (idx !== -1) activeSelection.splice(idx, 1);
  }
}
function activeToggle(p) {
  if (activeSelectionSet.has(p)) activeRemove(p); else activeAdd(p);
}
function activeClear() {
  activeSelection = [];
  activeSelectionSet = new Set();
}

// ---------- Element refs ----------

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const dropzoneSection = document.getElementById('dropzoneSection');
const editorSection = document.getElementById('editorSection');
const fileNameEl = document.getElementById('fileName');
const fileMetaEl = document.getElementById('fileMeta');
const tabVisual = document.getElementById('tabVisual');
const tabManual = document.getElementById('tabManual');
const visualPanel = document.getElementById('visualPanel');
const manualPanel = document.getElementById('manualPanel');
const modeHint = document.getElementById('modeHint');
const pageGrid = document.getElementById('pageGrid');
const btnConfirmRange = document.getElementById('btnConfirmRange');
const manualRowsContainer = document.getElementById('manualRows');
const chipsRow = document.getElementById('chipsRow');
const noSelectionText = document.getElementById('noSelectionText');
const btnSplit = document.getElementById('btnSplit');
const progressWrap = document.getElementById('progressWrap');
const progressFill = document.getElementById('progressFill');
const progressLabel = document.getElementById('progressLabel');
const resultPanel = document.getElementById('resultPanel');
const resultText = document.getElementById('resultText');
const btnDownloadZip = document.getElementById('btnDownloadZip');
const zoomModal = document.getElementById('zoomModal');
const zoomImage = document.getElementById('zoomImage');
const zoomLabel = document.getElementById('zoomLabel');

const VISUAL_HINT =
  "Tap any pages \u2014 they don't need to be next to each other, and a page can be in more " +
  'than one file. Confirm a range to save it and start fresh.';
const MANUAL_HINT =
  'Type page numbers or ranges per file, e.g. 1-5, 9, 12-14 \u2014 each row becomes its own file.';

// ---------- File loading ----------

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    fileInput.click();
  }
});
fileInput.addEventListener('change', (e) => {
  if (e.target.files && e.target.files[0]) loadFile(e.target.files[0]);
});

['dragover', 'dragenter'].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add('drag-over');
  })
);
['dragleave', 'drop'].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove('drag-over');
  })
);
dropzone.addEventListener('drop', (e) => {
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (file) loadFile(file);
});

document.getElementById('btnChangeFile').addEventListener('click', resetToDropzone);

async function loadFile(file) {
  const looksLikePdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
  if (!looksLikePdf) {
    alert('Please choose a PDF file.');
    return;
  }

  try {
    fileName = file.name;
    const buf = await file.arrayBuffer();
    pdfBytes = buf;

    const loadingTask = pdfjsLib.getDocument({ data: buf.slice(0) });
    pdfDoc = await loadingTask.promise;
    totalPages = pdfDoc.numPages;

    committedRanges = [];
    activeClear();
    thumbnailCache.clear();

    fileNameEl.textContent = fileName;
    fileMetaEl.textContent = totalPages + (totalPages === 1 ? ' page' : ' pages');

    dropzoneSection.style.display = 'none';
    editorSection.style.display = 'block';

    currentMode = 'visual';
    applyModeVisuals();
    buildPageGrid();
    updateSelectionUi();
  } catch (err) {
    alert("This file couldn't be opened. Please choose a valid PDF.");
  }
}

function resetToDropzone() {
  pdfDoc = null;
  pdfBytes = null;
  totalPages = 0;
  committedRanges = [];
  activeClear();
  thumbnailCache.clear();
  pageGrid.innerHTML = '';
  manualRowsContainer.innerHTML = '';
  manualRows = [];
  resultPanel.classList.remove('visible');
  editorSection.style.display = 'none';
  dropzoneSection.style.display = 'block';
  fileInput.value = '';
}

// ---------- Page grid (Visual mode) ----------

function buildPageGrid() {
  pageGrid.innerHTML = '';
  const fragment = document.createDocumentFragment();

  for (let p = 1; p <= totalPages; p++) {
    const tile = document.createElement('div');
    tile.className = 'page-tile';
    tile.dataset.page = String(p);
    tile.setAttribute('role', 'button');
    tile.setAttribute('aria-label', 'Page ' + p);

    const badge = document.createElement('span');
    badge.className = 'page-num-badge';
    badge.textContent = String(p);

    const check = document.createElement('span');
    check.className = 'page-check';
    check.innerHTML = '&#10003;';
    check.setAttribute('aria-hidden', 'true');

    const zoomBtn = document.createElement('button');
    zoomBtn.className = 'page-zoom-btn';
    zoomBtn.type = 'button';
    zoomBtn.innerHTML = '&#128269;';
    zoomBtn.setAttribute('aria-label', 'Preview page ' + p);
    zoomBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openZoom(p);
    });

    tile.appendChild(badge);
    tile.appendChild(check);
    tile.appendChild(zoomBtn);
    tile.addEventListener('click', () => onPageTapped(p));

    fragment.appendChild(tile);
  }

  pageGrid.appendChild(fragment);

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const tile = entry.target;
          const p = parseInt(tile.dataset.page, 10);
          renderThumbnailInto(tile, p);
          observer.unobserve(tile);
        }
      });
    },
    { rootMargin: '250px' }
  );

  pageGrid.querySelectorAll('.page-tile').forEach((tile) => observer.observe(tile));
}

async function renderThumbnailInto(tile, pageNum) {
  try {
    let dataUrl = thumbnailCache.get(pageNum);
    if (!dataUrl) {
      dataUrl = await renderPageToDataUrl(pageNum, 300);
      thumbnailCache.set(pageNum, dataUrl);
    }
    if (!tile.querySelector('img')) {
      const img = document.createElement('img');
      img.src = dataUrl;
      img.alt = '';
      tile.insertBefore(img, tile.firstChild);
    }
  } catch (err) {
    // Leave the tile blank on failure; the page number badge still shows.
  }
}

async function renderPageToDataUrl(pageNum, targetWidth) {
  const page = await pdfDoc.getPage(pageNum);
  const viewport = page.getViewport({ scale: 1 });
  const scale = targetWidth / viewport.width;
  const scaledViewport = page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = scaledViewport.width;
  canvas.height = scaledViewport.height;
  const ctx = canvas.getContext('2d');
  await page.render({ canvasContext: ctx, viewport: scaledViewport }).promise;
  return canvas.toDataURL('image/jpeg', 0.85);
}

function onPageTapped(p) {
  if (isProcessing) return;
  activeToggle(p);
  refreshTileState(p);
  updateSelectionUi();
}

function refreshTileState(p) {
  const tile = pageGrid.querySelector('.page-tile[data-page="' + p + '"]');
  if (!tile) return;
  tile.classList.toggle('active', activeSelectionSet.has(p));
}

function refreshAllTileStates() {
  pageGrid.querySelectorAll('.page-tile').forEach((tile) => {
    const p = parseInt(tile.dataset.page, 10);
    tile.classList.toggle('active', activeSelectionSet.has(p));
  });
}

// ---------- Zoom preview ----------

zoomModal.addEventListener('click', closeZoom);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeZoom();
});

async function openZoom(pageNum) {
  zoomLabel.textContent = 'Page ' + pageNum;
  zoomImage.src = '';
  zoomModal.classList.add('visible');
  try {
    const targetWidth = Math.min(window.innerWidth * 0.92, 1100);
    zoomImage.src = await renderPageToDataUrl(pageNum, targetWidth);
  } catch (err) {
    closeZoom();
  }
}

function closeZoom() {
  zoomModal.classList.remove('visible');
}

// ---------- Mode switching ----------

tabVisual.addEventListener('click', () => setMode('visual'));
tabManual.addEventListener('click', () => setMode('manual'));

function setMode(mode) {
  if (currentMode === mode) return;
  currentMode = mode;
  applyModeVisuals();
  refreshCurrentModeView();
}

function applyModeVisuals() {
  const visual = currentMode === 'visual';
  tabVisual.classList.toggle('active', visual);
  tabManual.classList.toggle('active', !visual);
  visualPanel.style.display = visual ? 'block' : 'none';
  manualPanel.style.display = visual ? 'none' : 'block';
  modeHint.textContent = visual ? VISUAL_HINT : MANUAL_HINT;
}

function refreshCurrentModeView() {
  if (currentMode === 'visual') {
    refreshAllTileStates();
  } else {
    populateManualRowsFromSelection();
  }
}

// ---------- Select all / Clear / Confirm ----------

document.getElementById('btnSelectAll').addEventListener('click', () => {
  if (isProcessing || totalPages === 0) return;
  activeClear();
  for (let p = 1; p <= totalPages; p++) activeAdd(p);
  refreshCurrentModeView();
  updateSelectionUi();
});

document.getElementById('btnClear').addEventListener('click', () => {
  if (isProcessing) return;
  activeClear();
  committedRanges = [];
  refreshCurrentModeView();
  updateSelectionUi();
});

btnConfirmRange.addEventListener('click', () => {
  if (isProcessing || activeSelection.length === 0) return;
  committedRanges.push(activeSelection.slice());
  activeClear();
  refreshCurrentModeView();
  updateSelectionUi();
});

// ---------- Manual mode ----------

function toIntToken(token) {
  if (!/^\d+$/.test(token)) return null;
  return parseInt(token, 10);
}

function parsePageList(text) {
  const seen = new Set();
  const pages = [];
  let error = null;
  const tokens = text.split(',').map((t) => t.trim()).filter((t) => t.length > 0);

  for (const token of tokens) {
    if (token.includes('-')) {
      const parts = token.split('-').map((t) => t.trim());
      const s = parts.length === 2 ? toIntToken(parts[0]) : null;
      const e = parts.length === 2 ? toIntToken(parts[1]) : null;
      if (s !== null && e !== null && s >= 1 && s <= totalPages && e >= 1 && e <= totalPages && s <= e) {
        for (let p = s; p <= e; p++) {
          if (!seen.has(p)) {
            seen.add(p);
            pages.push(p);
          }
        }
      } else {
        error = 'Check \u201c' + token + '\u201d';
      }
    } else {
      const p = toIntToken(token);
      if (p !== null && p >= 1 && p <= totalPages) {
        if (!seen.has(p)) {
          seen.add(p);
          pages.push(p);
        }
      } else {
        error = 'Check \u201c' + token + '\u201d';
      }
    }
  }
  return { pages, error };
}

function addManualRow(initialText) {
  const row = document.createElement('div');
  row.className = 'manual-row';

  const top = document.createElement('div');
  top.className = 'manual-row-top';

  const label = document.createElement('span');
  label.textContent = 'Range ' + (manualRows.length + 1);

  const delBtn = document.createElement('button');
  delBtn.className = 'icon-btn';
  delBtn.type = 'button';
  delBtn.innerHTML = '&#128465;';
  delBtn.setAttribute('aria-label', 'Remove range');

  top.appendChild(label);
  top.appendChild(delBtn);

  const input = document.createElement('input');
  input.type = 'text';
  input.placeholder = 'e.g. 1-5, 9, 12';
  if (initialText) input.value = initialText;

  const errorEl = document.createElement('div');
  errorEl.className = 'row-error';

  row.appendChild(top);
  row.appendChild(input);
  row.appendChild(errorEl);
  manualRowsContainer.appendChild(row);

  const rowObj = { el: row, input, errorEl, label };
  manualRows.push(rowObj);

  input.addEventListener('input', onManualRowChanged);
  delBtn.addEventListener('click', () => {
    if (isProcessing) return;
    manualRowsContainer.removeChild(row);
    manualRows = manualRows.filter((r) => r !== rowObj);
    relabelManualRows();
    onManualRowChanged();
  });

  relabelManualRows();
}

function relabelManualRows() {
  manualRows.forEach((r, i) => {
    r.label.textContent = 'Range ' + (i + 1);
  });
}

function onManualRowChanged() {
  committedRanges = [];
  manualRows.forEach((r) => {
    const text = r.input.value;
    if (!text.trim()) {
      r.el.classList.remove('has-error');
      r.errorEl.textContent = '';
      return;
    }
    const result = parsePageList(text);
    if (result.error) {
      r.el.classList.add('has-error');
      r.errorEl.textContent = result.error;
    } else {
      r.el.classList.remove('has-error');
      r.errorEl.textContent = '';
    }
    if (result.pages.length > 0) committedRanges.push(result.pages);
  });
  updateSelectionUi();
}

document.getElementById('btnAddManualRow').addEventListener('click', () => {
  if (isProcessing) return;
  let lastMax = null;
  manualRows.forEach((r) => {
    const res = parsePageList(r.input.value);
    if (res.pages.length > 0) {
      const m = Math.max(...res.pages);
      if (lastMax === null || m > lastMax) lastMax = m;
    }
  });
  const suggested = lastMax !== null && lastMax + 1 <= totalPages ? String(lastMax + 1) : '';
  addManualRow(suggested);
});

function populateManualRowsFromSelection() {
  manualRowsContainer.innerHTML = '';
  manualRows = [];

  const groups = committedRanges.slice();
  if (activeSelection.length > 0) groups.push(activeSelection.slice());
  activeClear();

  if (groups.length === 0) {
    addManualRow('');
  } else {
    groups.forEach((g) => addManualRow(formatForInput(g)));
  }
}

// ---------- Formatting ----------

function isSortedAscending(pages) {
  for (let i = 1; i < pages.length; i++) {
    if (pages[i] < pages[i - 1]) return false;
  }
  return true;
}

function collapseRuns(pages, dash) {
  if (pages.length === 0) return '';
  const sorted = pages.slice().sort((a, b) => a - b);
  const parts = [];
  let start = sorted[0];
  let prev = sorted[0];
  for (let i = 1; i < sorted.length; i++) {
    const cur = sorted[i];
    if (cur === prev + 1) {
      prev = cur;
    } else {
      parts.push(start === prev ? String(start) : start + dash + prev);
      start = cur;
      prev = cur;
    }
  }
  parts.push(start === prev ? String(start) : start + dash + prev);
  return parts.join(', ');
}

function formatForDisplay(pages) {
  return isSortedAscending(pages) ? collapseRuns(pages, '\u2013') : pages.join(', ');
}
function formatForInput(pages) {
  return isSortedAscending(pages) ? collapseRuns(pages, '-') : pages.join(', ');
}

// ---------- Chips / summary ----------

function updateSelectionUi() {
  chipsRow.innerHTML = '';
  const hasAnything = committedRanges.length > 0 || activeSelection.length > 0;

  if (!hasAnything) {
    noSelectionText.style.display = 'block';
    noSelectionText.textContent = 'No pages selected yet';
    chipsRow.style.display = 'none';
  } else {
    noSelectionText.style.display = 'none';
    chipsRow.style.display = 'flex';

    if (committedRanges.length > 0) {
      const filesPill = document.createElement('span');
      filesPill.className = 'chip pill-info';
      filesPill.textContent = 'Files: ' + committedRanges.length;
      chipsRow.appendChild(filesPill);
    }

    committedRanges.forEach((pages, index) => {
      const chip = document.createElement('span');
      chip.className = 'chip';

      const label = document.createElement('span');
      label.textContent = formatForDisplay(pages);
      label.style.cursor = 'pointer';
      label.addEventListener('click', () => {
        if (isProcessing || currentMode !== 'visual') return;
        editCommittedRange(index);
      });

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.innerHTML = '&times;';
      removeBtn.setAttribute('aria-label', 'Remove this range');
      removeBtn.addEventListener('click', () => {
        if (isProcessing) return;
        committedRanges.splice(index, 1);
        refreshCurrentModeView();
        updateSelectionUi();
      });

      chip.appendChild(label);
      chip.appendChild(removeBtn);
      chipsRow.appendChild(chip);
    });

    if (activeSelection.length > 0) {
      const activePill = document.createElement('span');
      activePill.className = 'chip pill-info';
      activePill.style.background = 'var(--coral-pale)';
      activePill.style.color = 'var(--coral-dark)';
      activePill.textContent = 'Selecting: ' + activeSelection.length;
      chipsRow.appendChild(activePill);
    }
  }

  btnSplit.disabled = !hasAnything || isProcessing;
  btnConfirmRange.disabled = activeSelection.length === 0 || isProcessing;
}

function editCommittedRange(index) {
  const pagesToEdit = committedRanges[index];
  if (!pagesToEdit) return;

  if (activeSelection.length > 0) {
    committedRanges.push(activeSelection.slice());
  }
  activeClear();
  committedRanges.splice(index, 1);
  pagesToEdit.forEach((p) => activeAdd(p));

  refreshAllTileStates();
  updateSelectionUi();
}

// ---------- Splitting ----------

btnSplit.addEventListener('click', performSplit);

async function performSplit() {
  if (!pdfBytes) return;

  if (activeSelection.length > 0) {
    committedRanges.push(activeSelection.slice());
    activeClear();
    refreshCurrentModeView();
    updateSelectionUi();
  }

  const groups = committedRanges.slice();
  if (groups.length === 0) return;

  isProcessing = true;
  setControlsEnabled(false);
  progressWrap.classList.add('visible');
  resultPanel.classList.remove('visible');
  progressFill.style.width = '0%';

  try {
    const baseName = sanitizedBaseName();
    const zip = new JSZip();
    const srcDoc = await PDFLib.PDFDocument.load(pdfBytes);

    for (let i = 0; i < groups.length; i++) {
      const group = groups[i];
      progressLabel.textContent = 'Creating file ' + (i + 1) + ' of ' + groups.length + '\u2026';
      progressFill.style.width = Math.round((i / groups.length) * 100) + '%';

      const newDoc = await PDFLib.PDFDocument.create();
      const indices = group.map((p) => p - 1);
      const copiedPages = await newDoc.copyPages(srcDoc, indices);
      copiedPages.forEach((pg) => newDoc.addPage(pg));
      const bytes = await newDoc.save();
      zip.file(baseName + '_' + describeGroupForFilename(group) + '.pdf', bytes);

      // Yield a tick so the progress bar actually repaints on large jobs.
      await new Promise((resolve) => setTimeout(resolve, 0));
    }

    progressFill.style.width = '100%';
    progressLabel.textContent = 'Packaging ZIP\u2026';

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(zipBlob);

    btnDownloadZip.href = url;
    btnDownloadZip.download = baseName + '_split.zip';

    resultText.textContent =
      groups.length + (groups.length === 1 ? ' PDF file' : ' PDF files') +
      ' packed into a ZIP, ready to download.';
    resultPanel.classList.add('visible');

    btnDownloadZip.click();
  } catch (err) {
    alert('Something went wrong while splitting: ' + (err && err.message ? err.message : err));
  } finally {
    isProcessing = false;
    setControlsEnabled(true);
    progressWrap.classList.remove('visible');
    btnSplit.disabled = committedRanges.length === 0 && activeSelection.length === 0;
  }
}

function setControlsEnabled(enabled) {
  document.getElementById('btnSelectAll').disabled = !enabled;
  document.getElementById('btnClear').disabled = !enabled;
  btnConfirmRange.disabled = !enabled || activeSelection.length === 0;
  btnSplit.disabled = !enabled;
}

function sanitizedBaseName() {
  let base = fileName.replace(/\.pdf$/i, '');
  base = base.replace(/[^a-zA-Z0-9_-]/g, '_');
  return base || 'document';
}

function describeGroupForFilename(pages) {
  if (pages.length === 0) return 'empty';
  const sorted = pages.slice().sort((a, b) => a - b);
  const parts = [];
  let start = sorted[0];
  let prev = sorted[0];
  for (let i = 1; i < sorted.length; i++) {
    const cur = sorted[i];
    if (cur === prev + 1) {
      prev = cur;
    } else {
      parts.push(start === prev ? 'p' + start : 'p' + start + '-' + prev);
      start = cur;
      prev = cur;
    }
  }
  parts.push(start === prev ? 'p' + start : 'p' + start + '-' + prev);
  return parts.join('_');
}
