# PDF Splitter — Website

A fully client-side companion site for PDF Splitter: a home page offering the Android app or
the web version, and a browser-based PDF splitter that needs no backend at all. Everything —
rendering pages, splitting the PDF, zipping the output — runs in the visitor's own browser via
three CDN-loaded libraries (pdf.js, pdf-lib, JSZip). Nothing is ever uploaded anywhere, which
makes it a natural fit for GitHub Pages (which only serves static files).

## Deploying to GitHub Pages

1. Create a new GitHub repository (or use one you already have) and push this folder's
   contents to it.
2. In the repo, go to **Settings → Pages**, and under "Build and deployment" set **Source** to
   "Deploy from a branch", branch `main`, folder `/ (root)`. Save.
3. GitHub gives you a URL like `https://<your-username>.github.io/<repo-name>/`. Wait a minute
   or two for the first deploy.

That's it — no build step, no `npm install`, nothing to compile.

## Before you publish: two things to update

1. **Replace the placeholder domain.** Every meta tag currently uses
   `https://example.github.io/pdf-splitter/` as a stand-in. Find-and-replace that string with
   your actual Pages URL in: `index.html`, `split.html`, `robots.txt`, `sitemap.xml`.
2. **Add the Android APK.** See `downloads/README.md` — drop your built `.apk` into the
   `downloads/` folder as `pdf-splitter.apk` and the home page's download button works
   immediately.

## Project layout

```
index.html              Home page: hero, the two options, SEO/OG/Twitter meta, JSON-LD
split.html               The web app itself
assets/css/style.css      All styles (shared design tokens, responsive layout)
assets/js/split.js        All the splitting logic (pdf.js + pdf-lib + JSZip)
assets/favicon.svg
assets/img/og-image.png   Social share preview image
downloads/                 Put your built APK here (see downloads/README.md)
robots.txt, sitemap.xml    Basic SEO plumbing
.nojekyll                  Tells GitHub Pages not to run Jekyll on this (plain static site)
```

## How the web app works

Mirrors the Android app's interaction model:

- **Visual Grid** — every page renders as a thumbnail (lazily, via `IntersectionObserver`, so
  large PDFs stay smooth). Tap any pages, in any order, even non-contiguous ones. Tap **Confirm
  range** to lock the current selection in as one output file and start a fresh selection — a
  page can be reused across multiple output files. Tap a confirmed chip to reopen it for
  editing. Tap the small magnifier on a thumbnail for a full-size preview.
- **Manual Ranges** — type page numbers/ranges per output file (e.g. `1-5, 9, 12-14`), one text
  field per range, with a button to add more.
- Pages land in the output PDF in the order you selected them (not sorted), same as the Android
  app — the chips display in tidy "1-3, 7" form when your selection happens to already be
  ascending, and plainly (e.g. "5, 1, 3") otherwise.
- **Split PDF** builds one `PDFDocument` per confirmed range via pdf-lib, zips them all with
  JSZip, and triggers a browser download — all in-memory, nothing touches a server.

## Browser support / device notes

Built with vanilla HTML/CSS/JS — no framework, no bundler. Works in any reasonably modern
browser (Chrome, Firefox, Safari, Edge, and their mobile equivalents) that supports ES2017+,
`IntersectionObserver`, and the Canvas API — which is effectively all browsers in active use.
Layout is responsive down to small phone widths (single-column choice cards, smaller grid
tiles below 480px).

## Swapping library versions

The three CDN scripts are pinned to specific versions in `split.html`:

- pdf.js `3.11.174` (classic global-script build, exposing `window.pdfjsLib`)
- pdf-lib `1.17.1`
- JSZip `3.10.1`

If you want newer versions, just change those two `<script src="...">` URLs (and the matching
`pdf.worker.min.js` URL at the top of `assets/js/split.js`) — check that whichever pdf.js
version you pick still ships a plain non-module `pdf.min.js` build, since some newer releases
have moved toward ES-module-only distribution.
