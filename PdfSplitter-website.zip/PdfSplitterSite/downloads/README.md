# Where the Android APK goes

Put your built APK in this folder, named exactly:

    pdf-splitter.apk

The home page's "Download APK" button links to `downloads/pdf-splitter.apk` (relative path).
Once you commit a file with that exact name here, the button works immediately - no other
code changes needed.

## Getting the APK

If you built it via the GitHub Actions workflow in the Android project (from the
`app/build/outputs/apk/debug/app-debug.apk` artifact), just download that artifact, rename it
to `pdf-splitter.apk`, and commit it into this folder.

## Alternative: link to a GitHub Release instead

If you'd rather not commit a binary file into this repo, you can instead create a GitHub
Release in your Android project's repo, upload the APK as a release asset, and update the two
`href="downloads/pdf-splitter.apk"` links (in `index.html`) to point at that release asset's
URL instead (something like
`https://github.com/<user>/<repo>/releases/download/<tag>/pdf-splitter.apk`).
